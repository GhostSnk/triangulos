﻿using System;

using Triangulos.Models;

namespace Triangulos
{

    class Controle : absPropriedades
    {

        private Models.Triangulos TriCheck;
        private Validacao validarTriangulo;

        public Controle ( String lado1 , String lado2 , String lado3 ) : base (lado1 , lado2 , lado3)
        {

            this.Verificar ();
        }
        private void Verificar ( )
        {
            try
            {
                L1 = Convert.ToDouble (this.Lado1);
                L2 = Convert.ToDouble (this.Lado2);
                L3 = Convert.ToDouble (this.Lado3);
                Console.WriteLine ($"{L1}{L2}{L3}");

                //verificar
                TriCheck = new Models.Triangulos (this.L1 , this.L2 , this.L3);
                if (TriCheck.Mensagem == "É um triângulo")
                {
                    //validar
                    validarTriangulo = new Validacao (this.Lado1 , this.Lado2 , this.Lado3);
                    this.Resposta = validarTriangulo.Resposta;

                }
                //caso não seja um triangulo
                else if (TriCheck.Mensagem == "Entrada invalida!")
                {
                    this.Resposta = TriCheck.Mensagem;
                }
            }
            catch
            {
                //caso entrada não seja numero
                this.Resposta = "Entrada Inválida";
            }


        }

    }
}
