﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

using System.Windows.Forms;

namespace Triangulos
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal ( )
        {
            InitializeComponent ();
        }
      Controle Controlador;

        private void btnVerificar_Click ( object sender , EventArgs e )
        {
            
            Controlador = new Controle(txbLado1.Text, txbLado2.Text, txbLado3.Text);
            lblResposta.Text = Controlador.Resposta;


        }
    }
}
