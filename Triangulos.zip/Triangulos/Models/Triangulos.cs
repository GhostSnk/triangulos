﻿using System;


namespace Triangulos.Models
{
    public class Triangulos :absPropriedades
    {
    public Triangulos(Double l1, Double l2, Double l3) : base (l1, l2, l3){
    this.Verificar();
    }

      private void Verificar(){

            try
            {
                //verificar se é um triangulo
                if ((this.L1 < this.L2 + this.L3) && (this.L2 < this.L1 + this.L3) && (this.L3 < this.L1 + this.L2))
                {
                    this.Mensagem = "É um triângulo";
                }
                

            }
            catch (Exception)
            {

                this.Mensagem = "Entrada invalida!";
            }

        }

    }
}
