﻿using System;


namespace Triangulos.Models
{
    class Validacao : absPropriedades
    {
        public Validacao ( String lado1 , String lado2 , String lado3 ) : base (lado1 , lado2 , lado3)
        {
            this.Validar ();
        }

        private void Validar ( )
        {
   

            try
            {
            //converter entrada do controller para double
                this.L1 = Convert.ToDouble (this.Lado1);
                this.L2 = Convert.ToDouble (this.Lado2);
                this.L3 = Convert.ToDouble (this.Lado3);

                if (this.L1 == this.L2 && this.L2 == this.L3)
                {
                    this.Resposta = "Triângulo Equilátero";
                }
                else if (this.L1 == this.L2 && this.L2 == this.L3 && this.L1 == this.L3)
                {
                    this.Resposta= "Triângulo Isósceles";
                }
                else{
                    this.Resposta = "Triângulo Escaleno";
                }
            }
            catch (Exception)
            {

                this.Mensagem = "Entrada invalida!";
            }
            finally{
                Console.WriteLine ($"{this.Resposta}");
            }

        }
    }
}
