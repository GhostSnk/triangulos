﻿using System;

namespace Triangulos.Models
{
    public abstract class absPropriedades
    {
        public Double L1;
        public Double L2;
        public Double L3;

        public String Lado1;
        public String Lado2;
        public String Lado3;

        public String Mensagem;
        public String Resposta;

        public absPropriedades ( Double l1 , Double l2 , Double l3 )
        {
            this.L1 = l1;
            this.L2 = l2;
            this.L3 = l3;

        }

        public absPropriedades ( String lado1 , String lado2 , String lado3 )
        {
            this.Lado1 = lado1;

            this.Lado2 = lado2;
            this.Lado3 = lado3;

        }


    }
}
